package com.mad2020reg.tasty;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainMenu extends AppCompatActivity {
    String gID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        /****Question 06 (a)  ****/
    }

    public void bookTable(View view){

        /****Question 06 (b)  ****/

    }


    public void takeaway(View view){

        /****Question 06 (c)  ****/

    }

    public void history(View view){

        /****Question 06 (d)  ****/
    }

    public void logout(View view){

        /****Question 06 (e)  ****/

    }
}