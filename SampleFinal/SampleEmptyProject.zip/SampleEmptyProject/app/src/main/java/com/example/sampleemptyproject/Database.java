package com.example.sampleemptyproject;

public class Database {


    // Question 7
    /*




     */

    // Question 8
    /*




     */
}
