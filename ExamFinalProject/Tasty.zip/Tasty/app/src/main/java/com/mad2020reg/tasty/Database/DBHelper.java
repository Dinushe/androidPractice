package com.mad2020reg.tasty.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

/****Question 03 (a) ****/

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Tasty.db";
    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String SQL_CREATE_ENTRIES =

                /****Question 03 (b)- (i) ****/


                db.execSQL(SQL_CREATE_ENTRIES);



        String SQL_CREATE_ENTRIES =

                /****Question 03 (b)- (ii) ****/


                db.execSQL(SQL_CREATE_ENTRIES);



        String SQL_CREATE_ENTRIES =


                /****Question 03 (b)- (iii) ****/


                db.execSQL(SQL_CREATE_ENTRIES);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    /****Question 03 (c) ****/

    public long addGuest(/***************/){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();


        // statements?



    }

    /****Question 03 (d) ****/

    public long addBooking(/**************/){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        // statements?



    }

    /****Question 03 (e) ****/
    public long addTakeaway(/*****************/){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        // statements?



    }

    //View Data

    public List getGuests(){




        /****Question 03 (f) ****/




    }

    public List getBookings(){




        /****Question 03 (g) ****/



    }

    public List getTakeaways(){


        /****Question 03 (h) ****/

    }



}
